#!/usr/bin/env python3
"""
PDF Briefing Generator — Daily Market Intelligence System
Generates a professional daily trading briefing PDF.

Usage: python generate_briefing_pdf.py
Requires: reportlab
"""

import json
import os
import sys
from datetime import datetime, timezone
from pathlib import Path

try:
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.lib.units import inch, mm
    from reportlab.platypus import (
        SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle,
        PageBreak, HRFlowable, KeepTogether
    )
    from reportlab.lib.enums import TA_LEFT, TA_CENTER, TA_RIGHT
except ImportError:
    os.system(f"{sys.executable} -m pip install reportlab --break-system-packages -q")
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.lib.units import inch, mm
    from reportlab.platypus import (
        SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle,
        PageBreak, HRFlowable, KeepTogether
    )
    from reportlab.lib.enums import TA_LEFT, TA_CENTER, TA_RIGHT

SCRIPT_DIR = Path(__file__).parent
PROJECT_ROOT = SCRIPT_DIR.parent
CONFIG_PATH = PROJECT_ROOT / "config" / "watchlist.json"
DATA_DIR = PROJECT_ROOT / "data" / "raw"

# ─── Color Palette ───────────────────────────────────────────────────────────

DARK_BG = colors.HexColor("#1a1a2e")
ACCENT_BLUE = colors.HexColor("#0f4c81")
ACCENT_GREEN = colors.HexColor("#2d6a4f")
ACCENT_RED = colors.HexColor("#c1121f")
ACCENT_AMBER = colors.HexColor("#e9971d")
LIGHT_GRAY = colors.HexColor("#f5f5f5")
MID_GRAY = colors.HexColor("#e0e0e0")
TEXT_PRIMARY = colors.HexColor("#1a1a1a")
TEXT_SECONDARY = colors.HexColor("#555555")
TEXT_MUTED = colors.HexColor("#888888")

# ─── Helpers ─────────────────────────────────────────────────────────────────

def load_config():
    with open(CONFIG_PATH) as f:
        return json.load(f)

def today_str():
    return datetime.now(timezone.utc).strftime("%Y-%m-%d")

def load_json(filename):
    path = DATA_DIR / filename
    try:
        with open(path) as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        return {}

def fmt_number(n, prefix="$", decimals=2):
    """Format a number with commas and optional prefix."""
    if n is None:
        return "N/A"
    try:
        n = float(n)
        if abs(n) >= 1_000_000_000:
            return f"{prefix}{n/1_000_000_000:.1f}B"
        elif abs(n) >= 1_000_000:
            return f"{prefix}{n/1_000_000:.1f}M"
        elif abs(n) >= 1_000:
            return f"{prefix}{n/1_000:.1f}K"
        else:
            return f"{prefix}{n:,.{decimals}f}"
    except:
        return str(n)

def fmt_pct(n):
    """Format as percentage."""
    if n is None:
        return "N/A"
    try:
        return f"{float(n):+.2f}%"
    except:
        return str(n)

def trend_color(value):
    """Return green for positive, red for negative."""
    try:
        return ACCENT_GREEN if float(value) >= 0 else ACCENT_RED
    except:
        return TEXT_PRIMARY

# ─── Custom Styles ───────────────────────────────────────────────────────────

def build_styles():
    styles = getSampleStyleSheet()
    
    styles.add(ParagraphStyle(
        name="CoverTitle",
        fontName="Helvetica-Bold",
        fontSize=28,
        textColor=ACCENT_BLUE,
        spaceAfter=6,
        alignment=TA_LEFT,
    ))
    styles.add(ParagraphStyle(
        name="CoverDate",
        fontName="Helvetica",
        fontSize=14,
        textColor=TEXT_SECONDARY,
        spaceAfter=20,
    ))
    styles.add(ParagraphStyle(
        name="SectionTitle",
        fontName="Helvetica-Bold",
        fontSize=16,
        textColor=ACCENT_BLUE,
        spaceBefore=20,
        spaceAfter=8,
        borderPadding=(0, 0, 4, 0),
    ))
    styles.add(ParagraphStyle(
        name="SubSection",
        fontName="Helvetica-Bold",
        fontSize=12,
        textColor=TEXT_PRIMARY,
        spaceBefore=12,
        spaceAfter=4,
    ))
    styles.add(ParagraphStyle(
        name="BodyText2",
        fontName="Helvetica",
        fontSize=10,
        textColor=TEXT_PRIMARY,
        spaceAfter=6,
        leading=14,
    ))
    styles.add(ParagraphStyle(
        name="SmallMuted",
        fontName="Helvetica",
        fontSize=8,
        textColor=TEXT_MUTED,
        spaceAfter=4,
    ))
    styles.add(ParagraphStyle(
        name="AlertBox",
        fontName="Helvetica-Bold",
        fontSize=11,
        textColor=colors.white,
        backColor=ACCENT_AMBER,
        borderPadding=(8, 8, 8, 8),
        spaceAfter=8,
    ))
    styles.add(ParagraphStyle(
        name="KeyTakeaway",
        fontName="Helvetica",
        fontSize=11,
        textColor=TEXT_PRIMARY,
        leftIndent=16,
        spaceAfter=4,
        bulletIndent=0,
        leading=15,
    ))
    
    return styles

# ─── Section Builders ────────────────────────────────────────────────────────

def build_cover_page(story, styles, market_data, technicals, confluence):
    """Build the cover page with date and key takeaways."""
    date = today_str()
    day_name = datetime.now().strftime("%A")
    
    story.append(Spacer(1, 40))
    story.append(Paragraph("DAILY MARKET<br/>INTELLIGENCE", styles["CoverTitle"]))
    story.append(Paragraph(f"{day_name}, {date}", styles["CoverDate"]))
    story.append(HRFlowable(width="100%", thickness=2, color=ACCENT_BLUE))
    story.append(Spacer(1, 20))
    
    # Market bias
    bias = technicals.get("summary", {}).get("market_bias", "neutral")
    bias_color = ACCENT_GREEN if bias == "bullish" else (ACCENT_RED if bias == "bearish" else ACCENT_AMBER)
    story.append(Paragraph(
        f'<font color="{bias_color.hexval()}" size="14"><b>Market Bias: {bias.upper()}</b></font>',
        styles["BodyText2"]
    ))
    story.append(Spacer(1, 12))
    
    # Key takeaways
    story.append(Paragraph("KEY TAKEAWAYS", styles["SubSection"]))
    
    takeaways = []
    summary = technicals.get("summary", {})
    if summary.get("bullish_count", 0) > summary.get("bearish_count", 0):
        takeaways.append(f"Majority of watchlist assets ({summary.get('bullish_count', 0)}/{summary.get('total_analyzed', 0)}) showing bullish technical structure")
    elif summary.get("bearish_count", 0) > summary.get("bullish_count", 0):
        takeaways.append(f"Caution: {summary.get('bearish_count', 0)}/{summary.get('total_analyzed', 0)} assets in bearish trend")
    
    if summary.get("total_alerts", 0) > 0:
        takeaways.append(f"{summary.get('total_alerts', 0)} technical alerts triggered across {summary.get('total_analyzed', 0)} assets")
    
    conf_count = confluence.get("confluence_count", 0)
    if conf_count > 0:
        takeaways.append(f"{conf_count} high-confluence setup(s) detected — see Confluence Alerts section")
    
    if not takeaways:
        takeaways.append("Markets in consolidation — no strong directional signals today")
    
    for t in takeaways[:5]:
        story.append(Paragraph(f"• {t}", styles["KeyTakeaway"]))
    
    story.append(PageBreak())

def build_market_overview(story, styles, market_data):
    """Build the market overview section."""
    story.append(Paragraph("1. MARKET OVERVIEW", styles["SectionTitle"]))
    story.append(HRFlowable(width="100%", thickness=0.5, color=MID_GRAY))
    
    # Stocks table
    stocks = market_data.get("stocks", {})
    if stocks:
        story.append(Paragraph("US Equities", styles["SubSection"]))
        
        table_data = [["Symbol", "Price", "Change", "Change %", "Volume"]]
        for symbol in ["SPY", "QQQ", "DIA", "IWM", "VIX"]:
            s = stocks.get(symbol, {})
            if s:
                table_data.append([
                    symbol,
                    fmt_number(s.get("price"), "$"),
                    fmt_number(s.get("change"), "$"),
                    s.get("change_percent", "N/A"),
                    fmt_number(s.get("volume"), "", 0),
                ])
        
        if len(table_data) > 1:
            t = Table(table_data, colWidths=[70, 80, 70, 70, 80])
            t.setStyle(TableStyle([
                ("BACKGROUND", (0, 0), (-1, 0), ACCENT_BLUE),
                ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
                ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
                ("FONTSIZE", (0, 0), (-1, -1), 9),
                ("ALIGN", (1, 0), (-1, -1), "RIGHT"),
                ("GRID", (0, 0), (-1, -1), 0.5, MID_GRAY),
                ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, LIGHT_GRAY]),
                ("TOPPADDING", (0, 0), (-1, -1), 4),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
            ]))
            story.append(t)
    
    # Crypto table
    crypto = market_data.get("crypto", [])
    if crypto:
        story.append(Spacer(1, 12))
        story.append(Paragraph("Crypto", styles["SubSection"]))
        
        table_data = [["Coin", "Price", "1H", "24H", "7D", "Market Cap"]]
        for c in crypto[:8]:
            table_data.append([
                c.get("symbol", ""),
                fmt_number(c.get("price"), "$"),
                fmt_pct(c.get("change_1h")),
                fmt_pct(c.get("change_24h")),
                fmt_pct(c.get("change_7d")),
                fmt_number(c.get("market_cap"), "$"),
            ])
        
        t = Table(table_data, colWidths=[50, 70, 50, 55, 55, 80])
        t.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), ACCENT_BLUE),
            ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
            ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
            ("FONTSIZE", (0, 0), (-1, -1), 9),
            ("ALIGN", (1, 0), (-1, -1), "RIGHT"),
            ("GRID", (0, 0), (-1, -1), 0.5, MID_GRAY),
            ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, LIGHT_GRAY]),
            ("TOPPADDING", (0, 0), (-1, -1), 4),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
        ]))
        story.append(t)
    
    # Forex
    forex = market_data.get("forex", [])
    if forex:
        story.append(Spacer(1, 12))
        story.append(Paragraph("Forex", styles["SubSection"]))
        table_data = [["Pair", "Rate", "Bid", "Ask"]]
        for f in forex:
            table_data.append([
                f.get("pair", ""),
                f"{f.get('rate', 0):.4f}",
                f"{f.get('bid', 0):.4f}",
                f"{f.get('ask', 0):.4f}",
            ])
        t = Table(table_data, colWidths=[80, 80, 80, 80])
        t.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), ACCENT_BLUE),
            ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
            ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
            ("FONTSIZE", (0, 0), (-1, -1), 9),
            ("ALIGN", (1, 0), (-1, -1), "RIGHT"),
            ("GRID", (0, 0), (-1, -1), 0.5, MID_GRAY),
            ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, LIGHT_GRAY]),
            ("TOPPADDING", (0, 0), (-1, -1), 4),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
        ]))
        story.append(t)

def build_technical_section(story, styles, technicals):
    """Build the technical analysis section."""
    story.append(PageBreak())
    story.append(Paragraph("2. TECHNICAL DASHBOARD", styles["SectionTitle"]))
    story.append(HRFlowable(width="100%", thickness=0.5, color=MID_GRAY))
    
    analyses = technicals.get("analyses", {})
    if not analyses:
        story.append(Paragraph("No technical data available. Check API keys and re-run.", styles["BodyText2"]))
        return
    
    table_data = [["Symbol", "Price", "Trend", "RSI", "MACD", "BB Pos", "Vol Ratio", "Alerts"]]
    
    for symbol, data in analyses.items():
        if data.get("error"):
            continue
        macd = data.get("macd", {})
        bb = data.get("bollinger_bands", {})
        trend = data.get("trend", "N/A")
        
        table_data.append([
            symbol,
            fmt_number(data.get("current_price"), "$"),
            trend.replace("_", " ").title(),
            str(data.get("rsi_14", "N/A")),
            macd.get("trend", "N/A").title() if macd else "N/A",
            bb.get("position", "N/A").replace("_", " ") if bb else "N/A",
            str(data.get("volume_ratio", "N/A")),
            str(data.get("alert_count", 0)),
        ])
    
    if len(table_data) > 1:
        t = Table(table_data, colWidths=[50, 60, 70, 40, 55, 70, 50, 40])
        t.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), ACCENT_BLUE),
            ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
            ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
            ("FONTSIZE", (0, 0), (-1, -1), 8),
            ("ALIGN", (1, 0), (-1, -1), "CENTER"),
            ("GRID", (0, 0), (-1, -1), 0.5, MID_GRAY),
            ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, LIGHT_GRAY]),
            ("TOPPADDING", (0, 0), (-1, -1), 3),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
        ]))
        story.append(t)
    
    # Detailed alerts
    story.append(Spacer(1, 12))
    story.append(Paragraph("Active Alerts", styles["SubSection"]))
    alert_found = False
    for symbol, data in analyses.items():
        alerts = data.get("alerts", [])
        if alerts:
            alert_found = True
            alert_text = ", ".join(a["type"].replace("_", " ") for a in alerts)
            story.append(Paragraph(f"<b>{symbol}:</b> {alert_text}", styles["BodyText2"]))
    if not alert_found:
        story.append(Paragraph("No alerts triggered today.", styles["BodyText2"]))

def build_traders_section(story, styles, traders_data, title, section_num):
    """Build a top traders section (works for both traditional and Polymarket)."""
    story.append(PageBreak())
    story.append(Paragraph(f"{section_num}. {title}", styles["SectionTitle"]))
    story.append(HRFlowable(width="100%", thickness=0.5, color=MID_GRAY))
    
    traders = traders_data.get("top_traders", [])
    if not traders:
        story.append(Paragraph("No trader data available. Check API configuration.", styles["BodyText2"]))
        return
    
    table_data = [["#", "Trader", "PnL", "Win Rate", "Positions", "Score", "Category"]]
    for i, t in enumerate(traders[:10]):
        table_data.append([
            str(i + 1),
            str(t.get("username", "anon"))[:15],
            fmt_number(t.get("total_pnl", 0), "$"),
            f"{t.get('win_rate', 0):.1%}" if isinstance(t.get("win_rate"), (int, float)) else str(t.get("win_rate", "N/A")),
            str(t.get("total_positions", t.get("active_positions", 0))),
            f"{t.get('composite_score', 0):.2f}",
            ", ".join(t.get("categories", ["N/A"])[:2]),
        ])
    
    t = Table(table_data, colWidths=[25, 80, 65, 55, 55, 45, 80])
    t.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), ACCENT_BLUE),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("FONTSIZE", (0, 0), (-1, -1), 8),
        ("ALIGN", (0, 0), (0, -1), "CENTER"),
        ("ALIGN", (2, 0), (5, -1), "RIGHT"),
        ("GRID", (0, 0), (-1, -1), 0.5, MID_GRAY),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, LIGHT_GRAY]),
        ("TOPPADDING", (0, 0), (-1, -1), 3),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
    ]))
    story.append(t)

def build_confluence_section(story, styles, confluence):
    """Build the high confluence alerts section."""
    story.append(PageBreak())
    story.append(Paragraph("5. HIGH CONFLUENCE ALERTS", styles["SectionTitle"]))
    story.append(HRFlowable(width="100%", thickness=0.5, color=MID_GRAY))
    
    story.append(Paragraph(
        "Confluence alerts fire when 3+ independent signal sources agree on the same directional thesis. "
        "More sources = higher confidence.",
        styles["SmallMuted"]
    ))
    story.append(Spacer(1, 8))
    
    confluences = confluence.get("confluences", [])
    if not confluences:
        story.append(Paragraph(
            "No high-confluence setups detected today. Individual signals may still present opportunities — "
            "review the Technical Dashboard and Trader sections independently.",
            styles["BodyText2"]
        ))
        return
    
    for i, c in enumerate(confluences):
        direction = c.get("direction", "").upper()
        dir_color = ACCENT_GREEN if "BULL" in direction else ACCENT_RED
        
        story.append(Paragraph(
            f'<font color="{dir_color.hexval()}"><b>Alert #{i+1}: {c.get("symbol", "?")} — {direction}</b></font> '
            f'({c.get("confidence_label", "N/A")} confidence, {c.get("signal_count", 0)} signals)',
            styles["BodyText2"]
        ))
        story.append(Paragraph(
            f'Contributing sources: {", ".join(c.get("sources", []))}',
            styles["SmallMuted"]
        ))
        story.append(Spacer(1, 6))

def build_playbook(story, styles, technicals, confluence, market_data):
    """Build the daily playbook — actionable synthesis."""
    story.append(PageBreak())
    story.append(Paragraph("6. DAILY PLAYBOOK", styles["SectionTitle"]))
    story.append(HRFlowable(width="100%", thickness=0.5, color=MID_GRAY))
    
    story.append(Paragraph(
        "<i>This section synthesizes all data into actionable guidance. "
        "Not financial advice — use your own judgment and risk management.</i>",
        styles["SmallMuted"]
    ))
    story.append(Spacer(1, 8))
    
    bias = technicals.get("summary", {}).get("market_bias", "neutral")
    
    story.append(Paragraph("Market Posture", styles["SubSection"]))
    if bias == "bullish":
        story.append(Paragraph(
            "Technical structure favors longs today. Focus on pullback entries in uptrending names. "
            "Use trailing stops to protect gains. Watch for volume confirmation on breakouts.",
            styles["BodyText2"]
        ))
    elif bias == "bearish":
        story.append(Paragraph(
            "Technical structure favors caution. Consider reducing position sizes or hedging. "
            "Look for short setups at resistance levels with volume confirmation. "
            "Keep tight stop-losses.",
            styles["BodyText2"]
        ))
    else:
        story.append(Paragraph(
            "Mixed signals — no clear directional edge. Range-bound strategies (mean reversion, "
            "selling premium) may outperform directional trades. Wait for cleaner setups.",
            styles["BodyText2"]
        ))
    
    story.append(Paragraph("Risk Reminders", styles["SubSection"]))
    story.append(Paragraph("• Never risk more than 1-2% of portfolio on a single trade", styles["KeyTakeaway"]))
    story.append(Paragraph("• Set stops before entering — not after", styles["KeyTakeaway"]))
    story.append(Paragraph("• Confluence alerts are signals, not certainties", styles["KeyTakeaway"]))
    story.append(Paragraph("• Track your trades against this briefing in the Notion archive", styles["KeyTakeaway"]))
    
    # Economic calendar
    econ = market_data.get("economic_calendar", [])
    if econ:
        story.append(Spacer(1, 8))
        story.append(Paragraph("Economic Events to Watch", styles["SubSection"]))
        for event in econ[:5]:
            impact = event.get("impact", "low")
            marker = "!!!" if impact == "high" else ("!" if impact == "medium" else "")
            story.append(Paragraph(
                f"• {event.get('time', '')} — {event.get('event', '')} ({event.get('country', '')}) {marker}",
                styles["KeyTakeaway"]
            ))

def build_footer(canvas_obj, doc):
    """Add footer to each page."""
    canvas_obj.saveState()
    canvas_obj.setFont("Helvetica", 7)
    canvas_obj.setFillColor(TEXT_MUTED)
    canvas_obj.drawString(
        40, 20,
        f"Daily Market Intelligence — {today_str()} — Generated by Claude Code Scheduled Task"
    )
    canvas_obj.drawRightString(
        A4[0] - 40, 20,
        f"Page {doc.page}"
    )
    canvas_obj.restoreState()

# ─── Main ────────────────────────────────────────────────────────────────────

def main():
    print(f"{'='*60}")
    print(f"  PDF BRIEFING GENERATOR — {today_str()}")
    print(f"{'='*60}")
    
    config = load_config()
    date = today_str()
    styles = build_styles()
    
    # Load all data
    print("\nLoading data sources...")
    market_data = load_json(f"market_data_{date}.json")
    technicals = load_json(f"technicals_{date}.json")
    traders = load_json(f"top_traders_{date}.json")
    pm_traders = load_json(f"polymarket_traders_{date}.json")
    confluence = load_json(f"confluence_{date}.json")
    
    # Create output directory
    output_dir = Path(os.path.expanduser(config["output"]["pdf_directory"]))
    output_dir.mkdir(parents=True, exist_ok=True)
    
    filename = config["output"]["pdf_filename_format"].format(date=date)
    output_path = output_dir / filename
    
    # Build PDF
    print(f"\nGenerating PDF: {output_path}")
    doc = SimpleDocTemplate(
        str(output_path),
        pagesize=A4,
        leftMargin=40,
        rightMargin=40,
        topMargin=40,
        bottomMargin=40,
    )
    
    story = []
    
    # Cover page
    print("  Building cover page...")
    build_cover_page(story, styles, market_data, technicals, confluence)
    
    # Market overview
    print("  Building market overview...")
    build_market_overview(story, styles, market_data)
    
    # Technical dashboard
    print("  Building technical dashboard...")
    build_technical_section(story, styles, technicals)
    
    # Top traders
    print("  Building top traders (traditional)...")
    build_traders_section(story, styles, traders, "TOP 10 TRENDING TRADERS", "3")
    
    # Polymarket traders
    print("  Building top Polymarket accounts...")
    build_traders_section(story, styles, pm_traders, "TOP 10 POLYMARKET ACCOUNTS", "4")
    
    # Confluence alerts
    print("  Building confluence alerts...")
    build_confluence_section(story, styles, confluence)
    
    # Daily playbook
    print("  Building daily playbook...")
    build_playbook(story, styles, technicals, confluence, market_data)
    
    # Build the PDF
    doc.build(story, onFirstPage=build_footer, onLaterPages=build_footer)
    
    print(f"\n{'='*60}")
    print(f"  PDF generated successfully!")
    print(f"  Location: {output_path}")
    print(f"  Size: {output_path.stat().st_size / 1024:.1f} KB")
    print(f"{'='*60}")
    
    return str(output_path)

if __name__ == "__main__":
    main()
