#!/usr/bin/env python3
"""
Market Data Fetcher — Daily Market Intelligence System
Fetches market data from multiple APIs and consolidates into a single JSON.

Usage: python fetch_market_data.py
Requires: requests, python-dateutil
API Keys: Set in config/watchlist.json
"""

import json
import os
import sys
from datetime import datetime, timezone
from pathlib import Path

try:
    import requests
except ImportError:
    print("Installing requests...")
    os.system(f"{sys.executable} -m pip install requests --break-system-packages -q")
    import requests

# ─── Configuration ───────────────────────────────────────────────────────────

SCRIPT_DIR = Path(__file__).parent
PROJECT_ROOT = SCRIPT_DIR.parent
CONFIG_PATH = PROJECT_ROOT / "config" / "watchlist.json"
DATA_DIR = PROJECT_ROOT / "data" / "raw"

def load_config():
    with open(CONFIG_PATH) as f:
        return json.load(f)

def today_str():
    return datetime.now(timezone.utc).strftime("%Y-%m-%d")

# ─── Alpha Vantage — Stocks & Forex ─────────────────────────────────────────

def fetch_stock_quote(symbol, api_key):
    """Fetch real-time quote for a stock symbol."""
    url = "https://www.alphavantage.co/query"
    params = {
        "function": "GLOBAL_QUOTE",
        "symbol": symbol,
        "apikey": api_key
    }
    try:
        resp = requests.get(url, params=params, timeout=10)
        data = resp.json()
        quote = data.get("Global Quote", {})
        if not quote:
            return None
        return {
            "symbol": symbol,
            "price": float(quote.get("05. price", 0)),
            "change": float(quote.get("09. change", 0)),
            "change_percent": quote.get("10. change percent", "0%"),
            "volume": int(quote.get("06. volume", 0)),
            "previous_close": float(quote.get("08. previous close", 0)),
            "high": float(quote.get("03. high", 0)),
            "low": float(quote.get("04. low", 0)),
        }
    except Exception as e:
        print(f"  [WARN] Failed to fetch {symbol}: {e}")
        return None

def fetch_forex_rate(from_currency, to_currency, api_key):
    """Fetch forex exchange rate."""
    url = "https://www.alphavantage.co/query"
    params = {
        "function": "CURRENCY_EXCHANGE_RATE",
        "from_currency": from_currency,
        "to_currency": to_currency,
        "apikey": api_key
    }
    try:
        resp = requests.get(url, params=params, timeout=10)
        data = resp.json()
        rate_data = data.get("Realtime Currency Exchange Rate", {})
        if not rate_data:
            return None
        return {
            "pair": f"{from_currency}/{to_currency}",
            "rate": float(rate_data.get("5. Exchange Rate", 0)),
            "bid": float(rate_data.get("8. Bid Price", 0)),
            "ask": float(rate_data.get("9. Ask Price", 0)),
            "last_refreshed": rate_data.get("6. Last Refreshed", ""),
        }
    except Exception as e:
        print(f"  [WARN] Failed to fetch {from_currency}/{to_currency}: {e}")
        return None

# ─── CoinMarketCap — Crypto ─────────────────────────────────────────────────

def fetch_crypto_data(symbols, api_key):
    """Fetch crypto quotes from CoinMarketCap."""
    url = "https://pro-api.coinmarketcap.com/v1/cryptocurrency/quotes/latest"
    headers = {"X-CMC_PRO_API_KEY": api_key}
    params = {"symbol": ",".join(symbols), "convert": "USD"}
    try:
        resp = requests.get(url, headers=headers, params=params, timeout=10)
        data = resp.json()
        results = []
        for symbol in symbols:
            coin = data.get("data", {}).get(symbol)
            if coin:
                quote = coin["quote"]["USD"]
                results.append({
                    "symbol": symbol,
                    "name": coin["name"],
                    "price": round(quote["price"], 2),
                    "change_1h": round(quote.get("percent_change_1h", 0), 2),
                    "change_24h": round(quote.get("percent_change_24h", 0), 2),
                    "change_7d": round(quote.get("percent_change_7d", 0), 2),
                    "volume_24h": round(quote.get("volume_24h", 0), 0),
                    "market_cap": round(quote.get("market_cap", 0), 0),
                    "dominance": round(quote.get("market_cap_dominance", 0), 2),
                })
        return results
    except Exception as e:
        print(f"  [WARN] Failed to fetch crypto data: {e}")
        return []

# ─── Finnhub — Market News & Sentiment ───────────────────────────────────────

def fetch_market_news(api_key, category="general"):
    """Fetch market news from Finnhub."""
    url = "https://finnhub.io/api/v1/news"
    params = {"category": category, "token": api_key}
    try:
        resp = requests.get(url, params=params, timeout=10)
        articles = resp.json()
        return [{
            "headline": a.get("headline", ""),
            "source": a.get("source", ""),
            "url": a.get("url", ""),
            "summary": a.get("summary", "")[:200],
            "datetime": a.get("datetime", 0),
            "category": a.get("category", ""),
        } for a in articles[:15]]
    except Exception as e:
        print(f"  [WARN] Failed to fetch news: {e}")
        return []

def fetch_market_sentiment(symbol, api_key):
    """Fetch news sentiment for a symbol from Finnhub."""
    url = "https://finnhub.io/api/v1/news-sentiment"
    params = {"symbol": symbol, "token": api_key}
    try:
        resp = requests.get(url, params=params, timeout=10)
        data = resp.json()
        sentiment = data.get("sentiment", {})
        return {
            "symbol": symbol,
            "bullish_percent": sentiment.get("bullishPercent", 0),
            "bearish_percent": sentiment.get("bearishPercent", 0),
            "buzz_articles": data.get("buzz", {}).get("articlesInLastWeek", 0),
            "buzz_score": data.get("buzz", {}).get("buzz", 0),
            "sector_avg_bullish": data.get("sectorAverageBullishPercent", 0),
        }
    except Exception as e:
        print(f"  [WARN] Failed to fetch sentiment for {symbol}: {e}")
        return None

# ─── MarketAux — News with Entity Tagging ────────────────────────────────────

def fetch_tagged_news(api_key):
    """Fetch news with entity tagging and sentiment from MarketAux."""
    url = "https://api.marketaux.com/v1/news/all"
    params = {
        "api_token": api_key,
        "language": "en",
        "filter_entities": "true",
        "limit": 10,
    }
    try:
        resp = requests.get(url, params=params, timeout=10)
        data = resp.json()
        return [{
            "title": a.get("title", ""),
            "source": a.get("source", ""),
            "url": a.get("url", ""),
            "entities": [e.get("symbol", "") for e in a.get("entities", [])],
            "sentiment": a.get("entities", [{}])[0].get("sentiment_score", 0) if a.get("entities") else 0,
        } for a in data.get("data", [])[:10]]
    except Exception as e:
        print(f"  [WARN] Failed to fetch MarketAux news: {e}")
        return []

# ─── Economic Calendar (Finnhub) ─────────────────────────────────────────────

def fetch_economic_calendar(api_key):
    """Fetch today's economic events."""
    from datetime import timedelta
    today = today_str()
    tomorrow = (datetime.now(timezone.utc) + timedelta(days=1)).strftime("%Y-%m-%d")
    url = "https://finnhub.io/api/v1/calendar/economic"
    params = {"from": today, "to": tomorrow, "token": api_key}
    try:
        resp = requests.get(url, params=params, timeout=10)
        data = resp.json()
        events = data.get("economicCalendar", [])
        return [{
            "event": e.get("event", ""),
            "country": e.get("country", ""),
            "time": e.get("time", ""),
            "impact": e.get("impact", "low"),
            "previous": e.get("prev", ""),
            "forecast": e.get("estimate", ""),
            "actual": e.get("actual", ""),
        } for e in events[:20]]
    except Exception as e:
        print(f"  [WARN] Failed to fetch economic calendar: {e}")
        return []

# ─── Main Orchestrator ───────────────────────────────────────────────────────

def main():
    print(f"{'='*60}")
    print(f"  MARKET DATA FETCHER — {today_str()}")
    print(f"{'='*60}")

    config = load_config()
    keys = config["api_keys"]
    watchlist = config["watchlist"]
    
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    
    output = {
        "date": today_str(),
        "fetched_at": datetime.now(timezone.utc).isoformat(),
        "stocks": {},
        "crypto": [],
        "forex": [],
        "news": [],
        "tagged_news": [],
        "sentiment": [],
        "economic_calendar": [],
    }

    # --- Stocks ---
    print("\n[1/6] Fetching stock data...")
    all_tickers = (
        watchlist["us_stocks"]["indices"] +
        watchlist["us_stocks"]["large_cap"] +
        watchlist["us_stocks"]["momentum"] +
        watchlist["us_stocks"]["sectors"]
    )
    for ticker in all_tickers:
        quote = fetch_stock_quote(ticker, keys["alpha_vantage"])
        if quote:
            output["stocks"][ticker] = quote
            print(f"  ✓ {ticker}: ${quote['price']} ({quote['change_percent']})")
        # Alpha Vantage free tier: 5 calls/min — pace requests
        import time; time.sleep(12)

    # --- Crypto ---
    print("\n[2/6] Fetching crypto data...")
    all_crypto = (
        watchlist["crypto"]["major"] +
        watchlist["crypto"]["altcoins"] +
        watchlist["crypto"]["defi"]
    )
    output["crypto"] = fetch_crypto_data(all_crypto, keys["coinmarketcap"])
    for coin in output["crypto"]:
        print(f"  ✓ {coin['symbol']}: ${coin['price']} ({coin['change_24h']}%)")

    # --- Forex ---
    print("\n[3/6] Fetching forex rates...")
    for pair in watchlist["forex"]["major_pairs"] + watchlist["forex"]["cross_pairs"]:
        parts = pair.split("/")
        rate = fetch_forex_rate(parts[0], parts[1], keys["alpha_vantage"])
        if rate:
            output["forex"].append(rate)
            print(f"  ✓ {pair}: {rate['rate']}")
        import time; time.sleep(12)

    # --- News ---
    print("\n[4/6] Fetching market news...")
    output["news"] = fetch_market_news(keys["finnhub"])
    output["tagged_news"] = fetch_tagged_news(keys["marketaux_news"])
    print(f"  ✓ {len(output['news'])} general articles")
    print(f"  ✓ {len(output['tagged_news'])} entity-tagged articles")

    # --- Sentiment ---
    print("\n[5/6] Fetching sentiment data...")
    for symbol in ["AAPL", "MSFT", "NVDA", "TSLA", "SPY"]:
        sentiment = fetch_market_sentiment(symbol, keys["finnhub"])
        if sentiment:
            output["sentiment"].append(sentiment)
            print(f"  ✓ {symbol}: {sentiment['bullish_percent']}% bullish")

    # --- Economic Calendar ---
    print("\n[6/6] Fetching economic calendar...")
    output["economic_calendar"] = fetch_economic_calendar(keys["finnhub"])
    print(f"  ✓ {len(output['economic_calendar'])} events today")

    # --- Save ---
    outpath = DATA_DIR / f"market_data_{today_str()}.json"
    with open(outpath, "w") as f:
        json.dump(output, f, indent=2)
    
    print(f"\n{'='*60}")
    print(f"  Data saved to {outpath}")
    print(f"  Stocks: {len(output['stocks'])} | Crypto: {len(output['crypto'])} | Forex: {len(output['forex'])}")
    print(f"{'='*60}")
    return outpath

if __name__ == "__main__":
    main()
