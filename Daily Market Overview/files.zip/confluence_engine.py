#!/usr/bin/env python3
"""
Confluence Engine — Daily Market Intelligence System
Identifies multi-signal convergence for high-confidence trade setups.

When multiple independent signals align on the same thesis,
the probability of that thesis being correct increases significantly.

Usage: python confluence_engine.py
"""

import json
from datetime import datetime, timezone
from pathlib import Path

SCRIPT_DIR = Path(__file__).parent
PROJECT_ROOT = SCRIPT_DIR.parent
CONFIG_PATH = PROJECT_ROOT / "config" / "watchlist.json"
DATA_DIR = PROJECT_ROOT / "data" / "raw"

def load_config():
    with open(CONFIG_PATH) as f:
        return json.load(f)

def today_str():
    return datetime.now(timezone.utc).strftime("%Y-%m-%d")

def load_json(filename):
    path = DATA_DIR / filename
    try:
        with open(path) as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        return {}

# ─── Signal Extractors ──────────────────────────────────────────────────────

def extract_technical_signals(technicals):
    """Extract actionable signals from technical analysis data."""
    signals = []
    analyses = technicals.get("analyses", {})
    for symbol, data in analyses.items():
        if data.get("error"):
            continue
        for alert in data.get("alerts", []):
            direction = None
            strength = "moderate"
            if alert["type"] in ["oversold", "bullish_crossover", "bullish_divergence", "below_lower_band"]:
                direction = "bullish"
            elif alert["type"] in ["overbought", "bearish_crossover", "bearish_divergence", "above_upper_band"]:
                direction = "bearish"
            elif alert["type"] == "volume_spike":
                direction = data.get("trend", "neutral")
                if "bullish" in direction:
                    direction = "bullish"
                elif "bearish" in direction:
                    direction = "bearish"
                strength = "strong"
            elif alert["type"] == "golden_cross_uptrend":
                direction = "bullish"
                strength = "strong"
            elif alert["type"] == "death_cross_downtrend":
                direction = "bearish"
                strength = "strong"
            elif alert["type"] == "bollinger_squeeze":
                direction = "neutral_breakout_pending"
                strength = "watch"
            
            if direction and direction not in ["neutral", "neutral_breakout_pending"]:
                signals.append({
                    "source": "technical",
                    "symbol": symbol,
                    "direction": direction,
                    "signal_type": alert["type"],
                    "strength": strength,
                    "details": alert,
                })
    return signals

def extract_sentiment_signals(market_data):
    """Extract sentiment-based signals."""
    signals = []
    for s in market_data.get("sentiment", []):
        bullish = s.get("bullish_percent", 50)
        symbol = s.get("symbol", "")
        if bullish > 70:
            signals.append({
                "source": "sentiment",
                "symbol": symbol,
                "direction": "bullish",
                "signal_type": "strong_bullish_sentiment",
                "strength": "moderate",
                "details": {"bullish_percent": bullish, "buzz": s.get("buzz_score", 0)},
            })
        elif bullish < 30:
            signals.append({
                "source": "sentiment",
                "symbol": symbol,
                "direction": "bearish",
                "signal_type": "strong_bearish_sentiment",
                "strength": "moderate",
                "details": {"bullish_percent": bullish, "buzz": s.get("buzz_score", 0)},
            })
        if s.get("buzz_score", 0) > 2.0:
            signals.append({
                "source": "sentiment",
                "symbol": symbol,
                "direction": "high_attention",
                "signal_type": "unusual_buzz",
                "strength": "watch",
                "details": {"buzz_score": s.get("buzz_score", 0)},
            })
    return signals

def extract_news_signals(market_data):
    """Extract news catalyst signals."""
    signals = []
    for article in market_data.get("tagged_news", []):
        sentiment = article.get("sentiment", 0)
        entities = article.get("entities", [])
        if abs(sentiment) > 0.5 and entities:
            direction = "bullish" if sentiment > 0 else "bearish"
            for entity in entities:
                if entity:
                    signals.append({
                        "source": "news_catalyst",
                        "symbol": entity,
                        "direction": direction,
                        "signal_type": "news_sentiment",
                        "strength": "strong" if abs(sentiment) > 0.7 else "moderate",
                        "details": {"headline": article.get("title", "")[:100], "sentiment_score": sentiment},
                    })
    return signals

def extract_trader_signals(traders_data, source_type="traditional"):
    """Extract signals from top trader positions."""
    signals = []
    traders = traders_data.get("top_traders", [])
    for trader in traders:
        positions = trader.get("current_positions", trader.get("active_positions_detail", []))
        if isinstance(positions, list):
            for pos in positions:
                if isinstance(pos, dict):
                    symbol = pos.get("symbol", pos.get("market", ""))
                    direction = pos.get("direction", pos.get("side", ""))
                    if symbol and direction:
                        signals.append({
                            "source": f"top_trader_{source_type}",
                            "symbol": symbol,
                            "direction": direction.lower(),
                            "signal_type": "trader_position",
                            "strength": "moderate",
                            "details": {
                                "trader": trader.get("username", "anon"),
                                "trader_score": trader.get("composite_score", 0),
                                "win_rate": trader.get("win_rate", 0),
                            },
                        })
    return signals

def extract_polymarket_signals(pm_data):
    """Extract signals from Polymarket whale positions and trending markets."""
    signals = []
    for trader in pm_data.get("top_traders", []):
        # High-conviction traders entering positions is a signal
        if trader.get("conviction_score", 0) > 5:
            for cat in trader.get("categories", []):
                signals.append({
                    "source": "polymarket_whale",
                    "symbol": cat,
                    "direction": "high_conviction",
                    "signal_type": "whale_position",
                    "strength": "strong",
                    "details": {
                        "trader": trader.get("username", ""),
                        "pnl": trader.get("total_pnl", 0),
                        "conviction_score": trader.get("conviction_score", 0),
                    },
                })
    
    # Trending markets with extreme probabilities
    for market in pm_data.get("trending_markets", []):
        yes_price = market.get("yes_price")
        if yes_price is not None:
            try:
                price = float(yes_price)
                if price > 0.85:
                    signals.append({
                        "source": "polymarket_consensus",
                        "symbol": market.get("question", "")[:50],
                        "direction": "strong_yes",
                        "signal_type": "high_probability_market",
                        "strength": "strong",
                        "details": {"probability": price, "volume": market.get("volume_24h", 0)},
                    })
                elif price < 0.15:
                    signals.append({
                        "source": "polymarket_consensus",
                        "symbol": market.get("question", "")[:50],
                        "direction": "strong_no",
                        "signal_type": "low_probability_market",
                        "strength": "moderate",
                        "details": {"probability": price, "volume": market.get("volume_24h", 0)},
                    })
            except (ValueError, TypeError):
                pass
    return signals

# ─── Confluence Detection ────────────────────────────────────────────────────

def find_confluences(all_signals, min_signals=3):
    """
    Find cases where multiple independent signals converge on the same thesis.
    
    Confluence = same symbol (or related theme) + same direction + different sources.
    """
    # Group signals by symbol
    symbol_signals = {}
    for sig in all_signals:
        sym = sig["symbol"].upper() if sig["symbol"] else "GENERAL"
        if sym not in symbol_signals:
            symbol_signals[sym] = []
        symbol_signals[sym].append(sig)
    
    confluences = []
    for symbol, sigs in symbol_signals.items():
        # Check directional alignment
        bullish_sources = set()
        bearish_sources = set()
        all_details = []
        
        for sig in sigs:
            if sig["direction"] in ["bullish", "long", "buy", "strong_yes", "high_conviction"]:
                bullish_sources.add(sig["source"])
                all_details.append(sig)
            elif sig["direction"] in ["bearish", "short", "sell", "strong_no"]:
                bearish_sources.add(sig["source"])
                all_details.append(sig)
        
        # Confluence requires signals from different independent sources
        if len(bullish_sources) >= min_signals:
            strong_count = sum(1 for s in all_details if s.get("strength") == "strong" and "bullish" in s["direction"])
            confluences.append({
                "symbol": symbol,
                "direction": "bullish",
                "signal_count": len(bullish_sources),
                "sources": list(bullish_sources),
                "confidence": min(len(bullish_sources) / 5.0, 1.0),
                "confidence_label": _confidence_label(len(bullish_sources)),
                "strong_signals": strong_count,
                "contributing_signals": [s for s in all_details if s["direction"] in ["bullish", "long", "buy", "strong_yes", "high_conviction"]],
            })
        
        if len(bearish_sources) >= min_signals:
            strong_count = sum(1 for s in all_details if s.get("strength") == "strong" and "bearish" in s["direction"])
            confluences.append({
                "symbol": symbol,
                "direction": "bearish",
                "signal_count": len(bearish_sources),
                "sources": list(bearish_sources),
                "confidence": min(len(bearish_sources) / 5.0, 1.0),
                "confidence_label": _confidence_label(len(bearish_sources)),
                "strong_signals": strong_count,
                "contributing_signals": [s for s in all_details if s["direction"] in ["bearish", "short", "sell", "strong_no"]],
            })
    
    # Sort by signal count, then confidence
    confluences.sort(key=lambda x: (x["signal_count"], x["confidence"]), reverse=True)
    return confluences

def _confidence_label(signal_count):
    if signal_count >= 5:
        return "VERY HIGH"
    elif signal_count >= 4:
        return "HIGH"
    elif signal_count >= 3:
        return "MODERATE"
    return "LOW"

# ─── Main ────────────────────────────────────────────────────────────────────

def main():
    print(f"{'='*60}")
    print(f"  CONFLUENCE ENGINE — {today_str()}")
    print(f"{'='*60}")
    
    config = load_config()
    ce_config = config["confluence_engine"]
    
    # Load all data sources
    print("\nLoading data sources...")
    date = today_str()
    market_data = load_json(f"market_data_{date}.json")
    technicals = load_json(f"technicals_{date}.json")
    traders = load_json(f"top_traders_{date}.json")
    pm_traders = load_json(f"polymarket_traders_{date}.json")
    
    # Extract signals from each source
    print("Extracting signals...")
    all_signals = []
    
    tech_signals = extract_technical_signals(technicals)
    print(f"  Technical signals: {len(tech_signals)}")
    all_signals.extend(tech_signals)
    
    sent_signals = extract_sentiment_signals(market_data)
    print(f"  Sentiment signals: {len(sent_signals)}")
    all_signals.extend(sent_signals)
    
    news_signals = extract_news_signals(market_data)
    print(f"  News catalyst signals: {len(news_signals)}")
    all_signals.extend(news_signals)
    
    trader_signals = extract_trader_signals(traders, "traditional")
    print(f"  Traditional trader signals: {len(trader_signals)}")
    all_signals.extend(trader_signals)
    
    pm_signals = extract_polymarket_signals(pm_traders)
    print(f"  Polymarket signals: {len(pm_signals)}")
    all_signals.extend(pm_signals)
    
    total = len(all_signals)
    print(f"\n  Total signals collected: {total}")
    
    # Find confluences
    print(f"\nSearching for confluences (min {ce_config['min_signals_for_alert']} signals)...")
    confluences = find_confluences(all_signals, min_signals=ce_config["min_signals_for_alert"])
    
    # Cap at max alerts
    confluences = confluences[:ce_config["max_alerts_per_day"]]
    
    output = {
        "date": date,
        "total_signals_analyzed": total,
        "signal_breakdown": {
            "technical": len(tech_signals),
            "sentiment": len(sent_signals),
            "news_catalyst": len(news_signals),
            "trader_positions": len(trader_signals),
            "polymarket": len(pm_signals),
        },
        "confluences": confluences,
        "confluence_count": len(confluences),
        "all_signals": all_signals,
    }
    
    if confluences:
        print(f"\n  ★ Found {len(confluences)} confluence alert(s):")
        for i, c in enumerate(confluences):
            print(f"    #{i+1} {c['symbol']} — {c['direction'].upper()} "
                  f"({c['signal_count']} signals, {c['confidence_label']})")
            print(f"       Sources: {', '.join(c['sources'])}")
    else:
        print(f"\n  No confluences found today (min threshold: {ce_config['min_signals_for_alert']})")
    
    outpath = DATA_DIR / f"confluence_{date}.json"
    with open(outpath, "w") as f:
        json.dump(output, f, indent=2)
    
    print(f"\n{'='*60}")
    print(f"  Confluence analysis complete")
    print(f"  {len(confluences)} high-confidence alerts generated")
    print(f"  Saved to {outpath}")
    print(f"{'='*60}")

if __name__ == "__main__":
    main()
