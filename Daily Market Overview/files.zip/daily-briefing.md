# Daily Market Intelligence Briefing

Generate a comprehensive daily market intelligence briefing document. This is a scheduled task that runs every trading day.

## Pre-flight

1. Read the user config at `config/watchlist.json` to load personalized preferences
2. Read `data/trader_memory.json` to load historical trader performance data
3. Check today's date and determine if markets are open (skip weekends and major US holidays)

## Step 1 — Market Data Ingestion

Run `python scripts/fetch_market_data.py` to collect:

- **US Stocks**: S&P 500, NASDAQ, DOW futures/pre-market, VIX, top movers from watchlist
- **Crypto**: BTC, ETH, SOL, and coins from watchlist — price, 24h change, volume, dominance
- **Forex**: EUR/USD, GBP/USD, USD/JPY, and pairs from watchlist — price, daily range, trend
- **Economic Calendar**: Today's scheduled events (Fed speeches, earnings, data releases)
- **News Sentiment**: Top market-moving headlines with sentiment scores

Output: `data/raw/market_data_YYYY-MM-DD.json`

## Step 2 — Technical Analysis

Run `python scripts/technical_analysis.py` to compute:

- RSI (14), MACD, Bollinger Bands, 50/200 SMA, VWAP for each watchlist asset
- Support/resistance levels based on recent price action
- Volume analysis (above/below average, unusual spikes)
- Divergence detection (price vs RSI, price vs volume)
- Flag any asset in oversold (<30 RSI) or overbought (>70 RSI) territory
- Identify assets near key moving average crossovers

Output: `data/raw/technicals_YYYY-MM-DD.json`

## Step 3 — Top Trader Discovery (Traditional Markets)

Run `python scripts/discover_traders.py` to:

1. Query trading platform leaderboards and analytics APIs
2. Score each trader using the composite formula:
   - 30% win rate consistency (rolling 30-day)
   - 25% risk-adjusted returns (profit / max drawdown)
   - 20% trade frequency (active but not overtrading)
   - 15% specialization match (aligned with user's watchlist asset classes)
   - 10% recency (recent performance weighted higher)
3. Cross-reference with `data/trader_memory.json` — boost traders who performed well in past recommendations, penalize those who didn't
4. Select top 10 with diversity constraint: max 3 from same asset class
5. For each selected trader, capture: username/ID, platform, win rate, PnL, current open positions, recent notable trades

Output: `data/raw/top_traders_YYYY-MM-DD.json`

## Step 4 — Top Polymarket Accounts

Run `python scripts/discover_polymarket.py` to:

1. Query Polymarket leaderboard API (`GET /leaderboard`)
2. Cross-reference with Polymarket Analytics data for deeper metrics
3. Score using prediction market formula:
   - Win rate × ln(1 + total_resolved_positions) for skill vs luck separation
   - Category diversity or specialization (flag which: politics, sports, crypto, finance)
   - Position sizing patterns (conviction score: large bets vs small exploratory)
   - Active position count and unrealized PnL
4. Cross-reference with `data/trader_memory.json` for historical accuracy
5. Select top 10 with category diversity: at least 3 different categories represented
6. For each account, capture: username/wallet, total PnL, win rate, largest win, active positions with current probabilities, category specialization

Output: `data/raw/polymarket_traders_YYYY-MM-DD.json`

## Step 5 — Confluence Scoring

Run `python scripts/confluence_engine.py` to:

1. Load all data from steps 1-4
2. Identify convergence signals:
   - A top trader AND a Polymarket whale are aligned on the same directional thesis
   - Technical signals on an asset align with sentiment shift AND trader activity
   - Multiple independent Polymarket accounts entering the same position
   - News catalyst + technical breakout level + trader accumulation
3. Score each confluence from 1-5 (number of independent confirming signals)
4. Generate "High Confluence Alerts" for score ≥ 3

Output: `data/raw/confluence_YYYY-MM-DD.json`

## Step 6 — Generate PDF Briefing

Run `python scripts/generate_briefing_pdf.py` to create the daily PDF with sections:

### Document Structure
1. **Cover Page**: Date, market status summary, top 3 key takeaways
2. **Market Overview**: Indices, crypto, forex — overnight action, pre-market levels
3. **Economic Calendar**: Today's events ranked by expected market impact
4. **Technical Dashboard**: Watchlist assets with key levels, signals, and alerts
5. **Sentiment Pulse**: News sentiment score, Fear & Greed Index, unusual activity
6. **Top 10 Trending Traders**: Table with metrics + their current positions
7. **Top 10 Polymarket Accounts**: Table with metrics + active predictions
8. **High Confluence Alerts**: Multi-signal setups with confidence ratings
9. **Daily Playbook**: Actionable synthesis — what to watch, potential setups, risk warnings
10. **Performance Tracker**: How yesterday's recommendations performed

Output: `~/trading/daily-briefings/Market_Intel_YYYY-MM-DD.pdf`

## Step 7 — Update Memory & Archive

1. Run `python scripts/update_memory.py` to:
   - Score yesterday's trader recommendations against actual performance
   - Update `data/trader_memory.json` with new performance data
   - Calculate rolling accuracy metrics
2. Push the briefing summary to Notion using the Notion MCP integration for searchable archive

## Step 8 — Post-Run Summary

Print a brief summary to the terminal:
- Market sentiment (bullish/bearish/neutral)
- Number of high confluence alerts
- Top trader of the day
- Most interesting Polymarket position
- Path to the generated PDF
