#!/usr/bin/env python3
"""
Traditional Trader Discovery — Daily Market Intelligence System
Discovers top-performing traders from public trading platforms and leaderboards.

This script queries publicly available leaderboard data to find
consistently profitable traders across stocks, crypto, and forex.

Usage: python discover_traders.py

Data sources (public / free tier):
- TradingView public leaderboards
- eToro popular investor data (public)
- Copy trading platform leaderboards
- Social trading analytics

Note: Some platforms require scraping or API keys. This script
provides the framework — customize data sources to your platforms.
"""

import json
import math
import os
import sys
from datetime import datetime, timezone
from pathlib import Path

try:
    import requests
except ImportError:
    os.system(f"{sys.executable} -m pip install requests --break-system-packages -q")
    import requests

SCRIPT_DIR = Path(__file__).parent
PROJECT_ROOT = SCRIPT_DIR.parent
CONFIG_PATH = PROJECT_ROOT / "config" / "watchlist.json"
DATA_DIR = PROJECT_ROOT / "data" / "raw"
MEMORY_PATH = PROJECT_ROOT / "data" / "trader_memory.json"

def load_config():
    with open(CONFIG_PATH) as f:
        return json.load(f)

def load_memory():
    try:
        with open(MEMORY_PATH) as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        return {"traditional_traders": {}}

def today_str():
    return datetime.now(timezone.utc).strftime("%Y-%m-%d")

# ─── Scoring Functions ───────────────────────────────────────────────────────

def compute_composite_score(trader, weights, memory_data):
    """
    Composite score for ranking traders.
    
    Components:
    - Win rate consistency (30%): Rolling win rate with penalty for variance
    - Risk-adjusted returns (25%): Profit relative to max drawdown
    - Trade frequency (20%): Active but not overtrading
    - Specialization match (15%): Aligned with user's watchlist
    - Recency bonus (10%): Recent performance weighted higher
    
    Memory adjustment: Past accuracy boosts or penalizes score
    """
    win_rate = trader.get("win_rate", 0)
    pnl = trader.get("total_pnl", 0)
    max_dd = trader.get("max_drawdown", 1)
    trades = trader.get("total_trades", 0)
    recent_win_rate = trader.get("recent_win_rate", win_rate)
    asset_classes = trader.get("asset_classes", [])
    
    # Win rate consistency
    wr_score = win_rate * 10  # Scale to 0-10
    
    # Risk-adjusted returns
    risk_adj = pnl / max(abs(max_dd), 1)
    ra_score = min(math.log(1 + max(risk_adj, 0)) * 3, 10)
    
    # Trade frequency (penalize both extremes)
    if trades < 10:
        freq_score = trades / 10 * 5
    elif trades > 500:
        freq_score = 5  # Too many trades = possible noise
    else:
        freq_score = min(math.log(trades) * 2, 10)
    
    # Specialization match (simplified)
    spec_score = len(asset_classes) * 2 if asset_classes else 5
    
    # Recency
    recency_score = recent_win_rate * 10
    
    raw_score = (
        wr_score * weights["win_rate_consistency"] +
        ra_score * weights["risk_adjusted_returns"] +
        freq_score * weights["trade_frequency"] +
        spec_score * weights["specialization_match"] +
        recency_score * weights["recency_bonus"]
    )
    
    # Memory adjustment
    trader_id = trader.get("id", "")
    memory_boost = 1.0
    if trader_id in memory_data:
        mem = memory_data[trader_id]
        hits = mem.get("hits", 0)
        misses = mem.get("misses", 0)
        total = hits + misses
        if total >= 3:
            accuracy = hits / total
            if accuracy > 0.6:
                memory_boost = 1.5
            elif accuracy < 0.4:
                memory_boost = 0.7
    
    return round(raw_score * memory_boost, 4)

# ─── Data Collection ─────────────────────────────────────────────────────────
# NOTE: This section provides a framework for collecting trader data.
# Customize the data sources based on the trading platforms you use.
# The API calls below are illustrative — replace with actual endpoints.

def collect_sample_traders():
    """
    Collect trader data from available sources.
    
    In production, this would query:
    - TradingView public profiles
    - eToro CopyTrader leaderboard
    - Binance copy trading
    - Bybit USDT perpetual leaderboard
    - dYdX leaderboard
    
    For now, returns a structured format that the scoring engine processes.
    """
    # This is the schema each data source should normalize to:
    sample_schema = {
        "id": "trader_unique_id",
        "username": "display_name",
        "platform": "platform_name",
        "total_pnl": 0.0,
        "win_rate": 0.0,
        "total_trades": 0,
        "max_drawdown": 0.0,
        "recent_win_rate": 0.0,
        "asset_classes": ["stocks", "crypto"],
        "current_positions": [
            {"symbol": "AAPL", "direction": "long", "entry_price": 0, "size": 0}
        ],
        "profile_url": "https://...",
        "verified": False,
    }
    
    traders = []
    
    # === Add your data source integrations here ===
    # 
    # Example: Binance Futures leaderboard
    # try:
    #     resp = requests.get("https://www.binance.com/bapi/futures/v1/public/future/leaderboard/getLeaderboardRank",
    #         params={"isShared": True, "isTrader": True, "periodType": "WEEKLY", "limit": 20})
    #     data = resp.json()
    #     for d in data.get("data", []):
    #         traders.append({
    #             "id": d["encryptedUid"],
    #             "username": d.get("nickName", "anon"),
    #             "platform": "binance_futures",
    #             "total_pnl": d.get("pnl", 0),
    #             "win_rate": d.get("winRate", 0),
    #             ...
    #         })
    # except: pass
    #
    # Example: eToro popular investors
    # Example: dYdX leaderboard
    # Example: Bybit copy trading
    
    print(f"  Collected {len(traders)} traders from data sources")
    print("  TIP: Add your platform API integrations to discover_traders.py")
    print("  See comments in the code for integration examples")
    
    return traders

# ─── Main Pipeline ───────────────────────────────────────────────────────────

def main():
    print(f"{'='*60}")
    print(f"  TRADITIONAL TRADER DISCOVERY — {today_str()}")
    print(f"{'='*60}")
    
    config = load_config()
    weights = config["trader_discovery"]["scoring_weights"]
    memory = load_memory()
    memory_traders = memory.get("traditional_traders", {})
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    
    # Collect from all data sources
    print("\n[1/3] Collecting trader data from platforms...")
    traders = collect_sample_traders()
    
    # Score and rank
    print("\n[2/3] Scoring and ranking traders...")
    for trader in traders:
        trader["composite_score"] = compute_composite_score(trader, weights, memory_traders)
    
    traders.sort(key=lambda x: x.get("composite_score", 0), reverse=True)
    
    # Apply diversity constraint
    selected = []
    class_counts = {}
    max_per_class = config["trader_discovery"]["max_per_asset_class"]
    
    for trader in traders:
        classes = trader.get("asset_classes", ["general"])
        primary = classes[0] if classes else "general"
        count = class_counts.get(primary, 0)
        if count < max_per_class and len(selected) < 10:
            selected.append(trader)
            class_counts[primary] = count + 1
    
    output = {
        "date": today_str(),
        "top_traders": selected,
        "total_candidates": len(traders),
        "platforms_queried": list(set(t.get("platform", "unknown") for t in traders)),
    }
    
    print(f"\n[3/3] Selected top {len(selected)} traders")
    for i, t in enumerate(selected):
        print(f"  #{i+1} {t.get('username', 'anon')} ({t.get('platform', '?')}): "
              f"Score {t.get('composite_score', 0):.2f}")
    
    outpath = DATA_DIR / f"top_traders_{today_str()}.json"
    with open(outpath, "w") as f:
        json.dump(output, f, indent=2)
    
    print(f"\n{'='*60}")
    print(f"  Saved to {outpath}")
    print(f"{'='*60}")

if __name__ == "__main__":
    main()
