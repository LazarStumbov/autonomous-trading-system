#!/usr/bin/env python3
"""
Technical Analysis Engine — Daily Market Intelligence System
Computes technical indicators for all watchlist assets.

Usage: python technical_analysis.py
Requires: requests, numpy
"""

import json
import os
import sys
from datetime import datetime, timezone
from pathlib import Path

try:
    import numpy as np
except ImportError:
    os.system(f"{sys.executable} -m pip install numpy --break-system-packages -q")
    import numpy as np

try:
    import requests
except ImportError:
    os.system(f"{sys.executable} -m pip install requests --break-system-packages -q")
    import requests

SCRIPT_DIR = Path(__file__).parent
PROJECT_ROOT = SCRIPT_DIR.parent
CONFIG_PATH = PROJECT_ROOT / "config" / "watchlist.json"
DATA_DIR = PROJECT_ROOT / "data" / "raw"

def load_config():
    with open(CONFIG_PATH) as f:
        return json.load(f)

def today_str():
    return datetime.now(timezone.utc).strftime("%Y-%m-%d")

# ─── Indicator Calculations ──────────────────────────────────────────────────

def compute_rsi(prices, period=14):
    """Compute Relative Strength Index."""
    if len(prices) < period + 1:
        return None
    deltas = np.diff(prices)
    gains = np.where(deltas > 0, deltas, 0)
    losses = np.where(deltas < 0, -deltas, 0)
    avg_gain = np.mean(gains[:period])
    avg_loss = np.mean(losses[:period])
    if avg_loss == 0:
        return 100.0
    rs = avg_gain / avg_loss
    for i in range(period, len(gains)):
        avg_gain = (avg_gain * (period - 1) + gains[i]) / period
        avg_loss = (avg_loss * (period - 1) + losses[i]) / period
    if avg_loss == 0:
        return 100.0
    rs = avg_gain / avg_loss
    return round(100 - (100 / (1 + rs)), 2)

def compute_macd(prices, fast=12, slow=26, signal=9):
    """Compute MACD, signal line, and histogram."""
    if len(prices) < slow + signal:
        return None
    prices = np.array(prices, dtype=float)
    ema_fast = _ema(prices, fast)
    ema_slow = _ema(prices, slow)
    macd_line = ema_fast - ema_slow
    signal_line = _ema(macd_line, signal)
    histogram = macd_line - signal_line
    return {
        "macd": round(float(macd_line[-1]), 4),
        "signal": round(float(signal_line[-1]), 4),
        "histogram": round(float(histogram[-1]), 4),
        "trend": "bullish" if histogram[-1] > 0 else "bearish",
        "crossover": _detect_crossover(macd_line, signal_line),
    }

def compute_bollinger_bands(prices, period=20, std_dev=2):
    """Compute Bollinger Bands."""
    if len(prices) < period:
        return None
    prices = np.array(prices, dtype=float)
    sma = np.mean(prices[-period:])
    std = np.std(prices[-period:])
    current = float(prices[-1])
    upper = sma + (std_dev * std)
    lower = sma - (std_dev * std)
    bandwidth = (upper - lower) / sma if sma != 0 else 0
    return {
        "upper": round(upper, 2),
        "middle": round(sma, 2),
        "lower": round(lower, 2),
        "current_price": round(current, 2),
        "bandwidth": round(bandwidth, 4),
        "percent_b": round((current - lower) / (upper - lower), 4) if (upper - lower) != 0 else 0.5,
        "squeeze": bandwidth < 0.05,
        "position": "above_upper" if current > upper else ("below_lower" if current < lower else "within_bands"),
    }

def compute_sma(prices, period):
    """Compute Simple Moving Average."""
    if len(prices) < period:
        return None
    return round(float(np.mean(prices[-period:])), 2)

def compute_atr(highs, lows, closes, period=14):
    """Compute Average True Range."""
    if len(closes) < period + 1:
        return None
    trs = []
    for i in range(1, len(closes)):
        tr = max(
            highs[i] - lows[i],
            abs(highs[i] - closes[i-1]),
            abs(lows[i] - closes[i-1])
        )
        trs.append(tr)
    return round(float(np.mean(trs[-period:])), 2)

def detect_divergence(prices, rsi_values):
    """Detect bullish/bearish divergence between price and RSI."""
    if len(prices) < 20 or len(rsi_values) < 20:
        return None
    recent_prices = prices[-20:]
    recent_rsi = rsi_values[-20:]
    price_trend = "up" if recent_prices[-1] > recent_prices[0] else "down"
    rsi_trend = "up" if recent_rsi[-1] > recent_rsi[0] else "down"
    if price_trend == "up" and rsi_trend == "down":
        return "bearish_divergence"
    elif price_trend == "down" and rsi_trend == "up":
        return "bullish_divergence"
    return None

def find_support_resistance(prices, window=5):
    """Find support and resistance levels from recent price data."""
    if len(prices) < window * 2:
        return {"support": [], "resistance": []}
    prices = np.array(prices, dtype=float)
    supports = []
    resistances = []
    for i in range(window, len(prices) - window):
        if all(prices[i] <= prices[i-j] for j in range(1, window+1)) and \
           all(prices[i] <= prices[i+j] for j in range(1, window+1)):
            supports.append(round(float(prices[i]), 2))
        if all(prices[i] >= prices[i-j] for j in range(1, window+1)) and \
           all(prices[i] >= prices[i+j] for j in range(1, window+1)):
            resistances.append(round(float(prices[i]), 2))
    return {
        "support": sorted(set(supports))[-3:] if supports else [],
        "resistance": sorted(set(resistances))[:3] if resistances else [],
    }

# ─── Helpers ─────────────────────────────────────────────────────────────────

def _ema(data, period):
    """Compute Exponential Moving Average."""
    data = np.array(data, dtype=float)
    multiplier = 2 / (period + 1)
    ema = np.zeros_like(data)
    ema[:period] = np.mean(data[:period])
    for i in range(period, len(data)):
        ema[i] = (data[i] - ema[i-1]) * multiplier + ema[i-1]
    return ema

def _detect_crossover(fast, slow):
    """Detect if a crossover happened in the last 2 bars."""
    if len(fast) < 3 or len(slow) < 3:
        return None
    if fast[-2] < slow[-2] and fast[-1] > slow[-1]:
        return "bullish_crossover"
    elif fast[-2] > slow[-2] and fast[-1] < slow[-1]:
        return "bearish_crossover"
    return None

# ─── Data Fetching (Alpha Vantage daily series) ─────────────────────────────

def fetch_daily_prices(symbol, api_key, outputsize="compact"):
    """Fetch daily OHLCV data for technical analysis."""
    url = "https://www.alphavantage.co/query"
    params = {
        "function": "TIME_SERIES_DAILY",
        "symbol": symbol,
        "outputsize": outputsize,
        "apikey": api_key,
    }
    try:
        resp = requests.get(url, params=params, timeout=15)
        data = resp.json()
        ts = data.get("Time Series (Daily)", {})
        if not ts:
            return None
        records = []
        for date in sorted(ts.keys()):
            d = ts[date]
            records.append({
                "date": date,
                "open": float(d["1. open"]),
                "high": float(d["2. high"]),
                "low": float(d["3. low"]),
                "close": float(d["4. close"]),
                "volume": int(d["5. volume"]),
            })
        return records
    except Exception as e:
        print(f"  [WARN] Failed to fetch daily prices for {symbol}: {e}")
        return None

# ─── Full Analysis for One Symbol ────────────────────────────────────────────

def analyze_symbol(symbol, daily_data):
    """Run full technical analysis suite on one symbol."""
    if not daily_data or len(daily_data) < 30:
        return {"symbol": symbol, "error": "Insufficient data"}
    
    closes = [d["close"] for d in daily_data]
    highs = [d["high"] for d in daily_data]
    lows = [d["low"] for d in daily_data]
    volumes = [d["volume"] for d in daily_data]
    current_price = closes[-1]
    
    rsi = compute_rsi(closes, 14)
    macd = compute_macd(closes)
    bb = compute_bollinger_bands(closes)
    sma_50 = compute_sma(closes, 50)
    sma_200 = compute_sma(closes, 200)
    atr = compute_atr(highs, lows, closes, 14)
    sr_levels = find_support_resistance(closes)
    
    avg_volume = np.mean(volumes[-20:]) if len(volumes) >= 20 else np.mean(volumes)
    volume_ratio = round(volumes[-1] / avg_volume, 2) if avg_volume > 0 else 1.0
    
    # Generate alerts
    alerts = []
    if rsi is not None:
        if rsi < 30:
            alerts.append({"type": "oversold", "indicator": "RSI", "value": rsi})
        elif rsi > 70:
            alerts.append({"type": "overbought", "indicator": "RSI", "value": rsi})
    
    if bb and bb["squeeze"]:
        alerts.append({"type": "bollinger_squeeze", "bandwidth": bb["bandwidth"]})
    if bb and bb["position"] == "below_lower":
        alerts.append({"type": "below_lower_band"})
    if bb and bb["position"] == "above_upper":
        alerts.append({"type": "above_upper_band"})
    
    if macd and macd["crossover"]:
        alerts.append({"type": macd["crossover"], "indicator": "MACD"})
    
    if sma_50 and sma_200:
        if sma_50 > sma_200 and current_price > sma_50:
            alerts.append({"type": "golden_cross_uptrend"})
        elif sma_50 < sma_200 and current_price < sma_50:
            alerts.append({"type": "death_cross_downtrend"})
        if abs(current_price - sma_200) / sma_200 < 0.02:
            alerts.append({"type": "near_200_sma", "distance_pct": round(abs(current_price - sma_200) / sma_200 * 100, 2)})
    
    if volume_ratio > 2.0:
        alerts.append({"type": "volume_spike", "ratio": volume_ratio})
    
    # Trend determination
    trend = "neutral"
    if sma_50 and current_price > sma_50:
        trend = "bullish" if (sma_200 and sma_50 > sma_200) else "mildly_bullish"
    elif sma_50 and current_price < sma_50:
        trend = "bearish" if (sma_200 and sma_50 < sma_200) else "mildly_bearish"
    
    return {
        "symbol": symbol,
        "current_price": round(current_price, 2),
        "trend": trend,
        "rsi_14": rsi,
        "macd": macd,
        "bollinger_bands": bb,
        "sma_50": sma_50,
        "sma_200": sma_200,
        "atr_14": atr,
        "support_resistance": sr_levels,
        "volume_ratio": volume_ratio,
        "avg_volume_20d": round(float(avg_volume), 0),
        "alerts": alerts,
        "alert_count": len(alerts),
        "last_5_closes": [round(c, 2) for c in closes[-5:]],
    }

# ─── Main ────────────────────────────────────────────────────────────────────

def main():
    import time
    
    print(f"{'='*60}")
    print(f"  TECHNICAL ANALYSIS ENGINE — {today_str()}")
    print(f"{'='*60}")
    
    config = load_config()
    api_key = config["api_keys"]["alpha_vantage"]
    watchlist = config["watchlist"]
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    
    # Build list of symbols to analyze
    symbols = (
        watchlist["us_stocks"]["indices"] +
        watchlist["us_stocks"]["large_cap"][:5] +  # Top 5 to stay within rate limits
        watchlist["us_stocks"]["momentum"][:3]
    )
    
    results = {"date": today_str(), "analyses": {}, "summary": {}}
    alert_total = 0
    
    for i, symbol in enumerate(symbols):
        print(f"\n[{i+1}/{len(symbols)}] Analyzing {symbol}...")
        daily = fetch_daily_prices(symbol, api_key)
        if daily:
            analysis = analyze_symbol(symbol, daily)
            results["analyses"][symbol] = analysis
            alert_total += analysis.get("alert_count", 0)
            print(f"  Trend: {analysis['trend']} | RSI: {analysis['rsi_14']} | Alerts: {analysis['alert_count']}")
            if analysis["alerts"]:
                for alert in analysis["alerts"]:
                    print(f"    ⚠ {alert['type']}")
        time.sleep(12)  # Rate limit: 5 calls/min on free tier
    
    # Summary
    bullish = sum(1 for a in results["analyses"].values() if "bullish" in a.get("trend", ""))
    bearish = sum(1 for a in results["analyses"].values() if "bearish" in a.get("trend", ""))
    results["summary"] = {
        "total_analyzed": len(results["analyses"]),
        "bullish_count": bullish,
        "bearish_count": bearish,
        "neutral_count": len(results["analyses"]) - bullish - bearish,
        "total_alerts": alert_total,
        "market_bias": "bullish" if bullish > bearish else ("bearish" if bearish > bullish else "neutral"),
        "most_alerted": sorted(
            results["analyses"].items(), 
            key=lambda x: x[1].get("alert_count", 0), 
            reverse=True
        )[:3],
    }
    results["summary"]["most_alerted"] = [
        {"symbol": s, "alerts": a["alert_count"]} 
        for s, a in results["summary"]["most_alerted"]
    ]
    
    outpath = DATA_DIR / f"technicals_{today_str()}.json"
    with open(outpath, "w") as f:
        json.dump(results, f, indent=2, default=str)
    
    print(f"\n{'='*60}")
    print(f"  Analysis complete: {results['summary']['total_analyzed']} symbols")
    print(f"  Market bias: {results['summary']['market_bias'].upper()}")
    print(f"  Total alerts: {alert_total}")
    print(f"  Saved to {outpath}")
    print(f"{'='*60}")

if __name__ == "__main__":
    main()
