#!/usr/bin/env python3
"""
Polymarket Trader Discovery — Daily Market Intelligence System
Discovers and ranks top-performing Polymarket prediction market traders.

Usage: python discover_polymarket.py
Requires: requests
"""

import json
import math
import os
import sys
from datetime import datetime, timezone
from pathlib import Path

try:
    import requests
except ImportError:
    os.system(f"{sys.executable} -m pip install requests --break-system-packages -q")
    import requests

SCRIPT_DIR = Path(__file__).parent
PROJECT_ROOT = SCRIPT_DIR.parent
CONFIG_PATH = PROJECT_ROOT / "config" / "watchlist.json"
DATA_DIR = PROJECT_ROOT / "data" / "raw"
MEMORY_PATH = PROJECT_ROOT / "data" / "trader_memory.json"

POLYMARKET_API = "https://gamma-api.polymarket.com"
POLYMARKET_CLOB = "https://clob.polymarket.com"

def load_config():
    with open(CONFIG_PATH) as f:
        return json.load(f)

def load_memory():
    try:
        with open(MEMORY_PATH) as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        return {"polymarket_traders": {}}

def today_str():
    return datetime.now(timezone.utc).strftime("%Y-%m-%d")

# ─── Polymarket API Calls ────────────────────────────────────────────────────

def fetch_leaderboard(limit=50):
    """Fetch the Polymarket leaderboard rankings."""
    url = f"{POLYMARKET_API}/leaderboard"
    params = {"limit": limit, "offset": 0}
    try:
        resp = requests.get(url, params=params, timeout=15)
        if resp.status_code == 200:
            return resp.json()
        # Fallback: try CLOB API
        url2 = f"{POLYMARKET_CLOB}/leaderboard"
        resp2 = requests.get(url2, params=params, timeout=15)
        return resp2.json() if resp2.status_code == 200 else []
    except Exception as e:
        print(f"  [WARN] Leaderboard fetch failed: {e}")
        return []

def fetch_trending_markets(limit=20):
    """Fetch currently trending/active markets."""
    url = f"{POLYMARKET_API}/markets"
    params = {"limit": limit, "active": True, "order": "volume24hr", "ascending": False}
    try:
        resp = requests.get(url, params=params, timeout=15)
        return resp.json() if resp.status_code == 200 else []
    except Exception as e:
        print(f"  [WARN] Trending markets fetch failed: {e}")
        return []

def fetch_market_details(market_id):
    """Fetch details for a specific market."""
    url = f"{POLYMARKET_API}/markets/{market_id}"
    try:
        resp = requests.get(url, timeout=10)
        return resp.json() if resp.status_code == 200 else None
    except:
        return None

def fetch_events(limit=10):
    """Fetch top events by volume."""
    url = f"{POLYMARKET_API}/events"
    params = {"limit": limit, "active": True, "order": "volume24hr", "ascending": False}
    try:
        resp = requests.get(url, params=params, timeout=15)
        return resp.json() if resp.status_code == 200 else []
    except Exception as e:
        print(f"  [WARN] Events fetch failed: {e}")
        return []

# ─── Trader Scoring Engine ───────────────────────────────────────────────────

def compute_skill_score(trader):
    """
    Compute skill score using: win_rate × ln(1 + total_positions)
    This separates genuine skill from lucky streaks.
    """
    win_rate = trader.get("win_rate", 0)
    total_positions = trader.get("total_positions", 0)
    if total_positions == 0:
        return 0
    return round(win_rate * math.log(1 + total_positions), 4)

def compute_conviction_score(trader):
    """
    Score based on position sizing patterns.
    High conviction = willing to size up on high-confidence plays.
    """
    largest_win = trader.get("largest_win", 0)
    total_pnl = trader.get("total_pnl", 1)
    active_positions = trader.get("active_positions", 0)
    if total_pnl <= 0:
        return 0
    concentration = largest_win / max(total_pnl, 1)
    return round(min(concentration * (1 + math.log(1 + active_positions)), 10), 2)

def compute_composite_score(trader, memory_data):
    """
    Full composite score incorporating memory of past performance.
    """
    skill = compute_skill_score(trader)
    conviction = compute_conviction_score(trader)
    pnl_score = math.log(1 + max(trader.get("total_pnl", 0), 0)) if trader.get("total_pnl", 0) > 0 else 0
    
    # Memory adjustment
    trader_id = trader.get("id", trader.get("username", ""))
    memory_boost = 1.0
    if trader_id in memory_data:
        mem = memory_data[trader_id]
        correct = mem.get("resolved_correct", 0)
        incorrect = mem.get("resolved_incorrect", 0)
        total = correct + incorrect
        if total >= 3:
            accuracy = correct / total
            if accuracy > 0.6:
                memory_boost = 1.5  # Boost reliable traders
            elif accuracy < 0.4:
                memory_boost = 0.7  # Penalize unreliable traders
    
    composite = (skill * 0.35 + pnl_score * 0.25 + conviction * 0.20 + (trader.get("win_rate", 0) * 10) * 0.20) * memory_boost
    return round(composite, 4)

def categorize_trader(trader):
    """Infer trader's category specialization from their positions."""
    categories = trader.get("categories", [])
    if categories:
        return categories
    # Fallback: infer from market names
    markets = trader.get("market_names", [])
    cats = set()
    keywords = {
        "politics": ["election", "president", "congress", "senate", "political", "trump", "biden", "vote"],
        "crypto": ["bitcoin", "btc", "ethereum", "eth", "crypto", "token", "defi", "solana"],
        "sports": ["nfl", "nba", "mlb", "soccer", "football", "basketball", "championship", "playoff"],
        "finance": ["fed", "interest rate", "gdp", "inflation", "stock", "recession", "earnings"],
        "tech": ["ai", "apple", "google", "microsoft", "openai", "tech", "launch"],
    }
    for market in markets:
        market_lower = market.lower()
        for cat, kws in keywords.items():
            if any(kw in market_lower for kw in kws):
                cats.add(cat)
    return list(cats) if cats else ["general"]

# ─── Main Discovery Pipeline ────────────────────────────────────────────────

def main():
    print(f"{'='*60}")
    print(f"  POLYMARKET TRADER DISCOVERY — {today_str()}")
    print(f"{'='*60}")
    
    config = load_config()
    pm_config = config["polymarket_config"]
    memory = load_memory()
    memory_traders = memory.get("polymarket_traders", {})
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    
    output = {
        "date": today_str(),
        "top_traders": [],
        "trending_markets": [],
        "top_events": [],
        "category_breakdown": {},
    }
    
    # Fetch leaderboard
    print("\n[1/3] Fetching Polymarket leaderboard...")
    leaderboard = fetch_leaderboard(limit=50)
    
    if isinstance(leaderboard, list):
        traders_raw = leaderboard
    elif isinstance(leaderboard, dict):
        traders_raw = leaderboard.get("traders", leaderboard.get("data", []))
    else:
        traders_raw = []
    
    print(f"  Retrieved {len(traders_raw)} traders from leaderboard")
    
    # Filter and score
    print("\n[2/3] Scoring and ranking traders...")
    scored_traders = []
    
    for trader in traders_raw:
        # Normalize field names (API formats vary)
        normalized = {
            "id": trader.get("id", trader.get("username", trader.get("address", "unknown"))),
            "username": trader.get("username", trader.get("name", trader.get("address", "anon")[:12])),
            "total_pnl": float(trader.get("pnl", trader.get("profit", trader.get("total_pnl", 0)))),
            "win_rate": float(trader.get("win_rate", trader.get("winRate", 0))),
            "total_positions": int(trader.get("positions", trader.get("total_positions", trader.get("trades", 0)))),
            "active_positions": int(trader.get("active_positions", trader.get("openPositions", 0))),
            "largest_win": float(trader.get("largest_win", trader.get("biggestWin", 0))),
            "volume": float(trader.get("volume", trader.get("total_volume", 0))),
            "categories": categorize_trader(trader),
        }
        
        # Apply minimum thresholds
        if normalized["total_positions"] < pm_config["min_trader_positions"]:
            continue
        if normalized["win_rate"] < pm_config["min_win_rate"]:
            continue
        if normalized["total_pnl"] <= 0:
            continue
        
        # Compute scores
        normalized["skill_score"] = compute_skill_score(normalized)
        normalized["conviction_score"] = compute_conviction_score(normalized)
        normalized["composite_score"] = compute_composite_score(normalized, memory_traders)
        
        scored_traders.append(normalized)
    
    # Sort by composite score
    scored_traders.sort(key=lambda x: x["composite_score"], reverse=True)
    
    # Apply diversity constraint: max 3 from same category
    selected = []
    category_counts = {}
    for trader in scored_traders:
        primary_cat = trader["categories"][0] if trader["categories"] else "general"
        count = category_counts.get(primary_cat, 0)
        if count < 3 and len(selected) < 10:
            selected.append(trader)
            category_counts[primary_cat] = count + 1
    
    output["top_traders"] = selected
    
    for i, t in enumerate(selected):
        print(f"  #{i+1} {t['username']}: PnL ${t['total_pnl']:,.0f} | "
              f"WR {t['win_rate']:.1%} | Score {t['composite_score']:.2f} | "
              f"Cat: {', '.join(t['categories'])}")
    
    # Category breakdown
    for t in selected:
        for cat in t["categories"]:
            if cat not in output["category_breakdown"]:
                output["category_breakdown"][cat] = 0
            output["category_breakdown"][cat] += 1
    
    # Fetch trending markets
    print("\n[3/3] Fetching trending markets and events...")
    markets = fetch_trending_markets(15)
    if isinstance(markets, list):
        output["trending_markets"] = [{
            "question": m.get("question", m.get("title", "")),
            "volume_24h": m.get("volume24hr", m.get("volume", 0)),
            "liquidity": m.get("liquidity", 0),
            "yes_price": m.get("outcomePrices", [None, None])[0] if isinstance(m.get("outcomePrices"), list) else m.get("bestBid", 0),
            "category": m.get("groupItemTitle", m.get("category", "")),
            "end_date": m.get("endDate", m.get("end_date_iso", "")),
        } for m in (markets if isinstance(markets, list) else [])][:10]
    
    events = fetch_events(10)
    if isinstance(events, list):
        output["top_events"] = [{
            "title": e.get("title", ""),
            "volume": e.get("volume", 0),
            "markets_count": len(e.get("markets", [])),
            "category": e.get("category", ""),
        } for e in events][:10]
    
    print(f"  {len(output['trending_markets'])} trending markets")
    print(f"  {len(output['top_events'])} top events")
    
    # Save
    outpath = DATA_DIR / f"polymarket_traders_{today_str()}.json"
    with open(outpath, "w") as f:
        json.dump(output, f, indent=2)
    
    print(f"\n{'='*60}")
    print(f"  Top 10 Polymarket traders selected")
    print(f"  Category mix: {output['category_breakdown']}")
    print(f"  Saved to {outpath}")
    print(f"{'='*60}")

if __name__ == "__main__":
    main()
