#!/usr/bin/env python3
"""
Memory Updater — Daily Market Intelligence System
Updates the rolling trader memory with performance tracking.

Tracks how recommended traders actually performed,
building a feedback loop that improves future recommendations.

Usage: python update_memory.py
"""

import json
from datetime import datetime, timezone, timedelta
from pathlib import Path

SCRIPT_DIR = Path(__file__).parent
PROJECT_ROOT = SCRIPT_DIR.parent
CONFIG_PATH = PROJECT_ROOT / "config" / "watchlist.json"
DATA_DIR = PROJECT_ROOT / "data" / "raw"
MEMORY_PATH = PROJECT_ROOT / "data" / "trader_memory.json"

def load_config():
    with open(CONFIG_PATH) as f:
        return json.load(f)

def today_str():
    return datetime.now(timezone.utc).strftime("%Y-%m-%d")

def load_json(filename):
    path = DATA_DIR / filename
    try:
        with open(path) as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        return {}

def load_memory():
    try:
        with open(MEMORY_PATH) as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        return {
            "version": "1.0",
            "last_updated": None,
            "traditional_traders": {},
            "polymarket_traders": {},
            "daily_recommendations_log": [],
            "accuracy_metrics": {
                "total_recommendations": 0,
                "correct_direction": 0,
                "profitable_within_5_days": 0,
                "average_return": 0,
                "rolling_30_day_accuracy": None,
            }
        }

def save_memory(memory):
    memory["last_updated"] = datetime.now(timezone.utc).isoformat()
    with open(MEMORY_PATH, "w") as f:
        json.dump(memory, f, indent=2)

# ─── Core Logic ──────────────────────────────────────────────────────────────

def update_traditional_traders(memory, traders_data, config):
    """Update memory with today's traditional trader recommendations."""
    traders = traders_data.get("top_traders", [])
    decay = config["trader_discovery"]["memory_decay_days"]
    
    for trader in traders:
        tid = str(trader.get("id", trader.get("username", "unknown")))
        
        if tid not in memory["traditional_traders"]:
            memory["traditional_traders"][tid] = {
                "platform": trader.get("platform", "unknown"),
                "first_recommended": today_str(),
                "times_recommended": 0,
                "hits": 0,
                "misses": 0,
                "cumulative_score": 0.0,
                "last_positions_snapshot": [],
                "last_seen": today_str(),
            }
        
        entry = memory["traditional_traders"][tid]
        entry["times_recommended"] += 1
        entry["last_seen"] = today_str()
        entry["cumulative_score"] = trader.get("composite_score", entry["cumulative_score"])
        
        # Snapshot current positions for future comparison
        positions = trader.get("current_positions", [])
        if isinstance(positions, list):
            entry["last_positions_snapshot"] = positions[:5]
    
    # Decay old entries
    cutoff = (datetime.now(timezone.utc) - timedelta(days=decay)).strftime("%Y-%m-%d")
    stale = [k for k, v in memory["traditional_traders"].items() if v.get("last_seen", "") < cutoff]
    for k in stale:
        del memory["traditional_traders"][k]
    
    return memory

def update_polymarket_traders(memory, pm_data, config):
    """Update memory with today's Polymarket trader recommendations."""
    traders = pm_data.get("top_traders", [])
    decay = config["trader_discovery"]["memory_decay_days"]
    
    for trader in traders:
        tid = str(trader.get("id", trader.get("username", "unknown")))
        
        if tid not in memory["polymarket_traders"]:
            memory["polymarket_traders"][tid] = {
                "first_recommended": today_str(),
                "times_recommended": 0,
                "resolved_correct": 0,
                "resolved_incorrect": 0,
                "unresolved": 0,
                "categories": [],
                "cumulative_score": 0.0,
                "last_positions_snapshot": [],
                "last_seen": today_str(),
            }
        
        entry = memory["polymarket_traders"][tid]
        entry["times_recommended"] += 1
        entry["last_seen"] = today_str()
        entry["cumulative_score"] = trader.get("composite_score", entry["cumulative_score"])
        entry["categories"] = trader.get("categories", entry["categories"])
        
        # Update resolved positions if available
        win_rate = trader.get("win_rate", 0)
        total = trader.get("total_positions", 0)
        if total > 0 and isinstance(win_rate, (int, float)):
            estimated_correct = int(total * win_rate)
            entry["resolved_correct"] = max(entry["resolved_correct"], estimated_correct)
            entry["resolved_incorrect"] = max(entry["resolved_incorrect"], total - estimated_correct)
    
    # Decay
    cutoff = (datetime.now(timezone.utc) - timedelta(days=decay)).strftime("%Y-%m-%d")
    stale = [k for k, v in memory["polymarket_traders"].items() if v.get("last_seen", "") < cutoff]
    for k in stale:
        del memory["polymarket_traders"][k]
    
    return memory

def log_daily_recommendation(memory, traders_data, pm_data, confluence):
    """Log today's recommendations for future tracking."""
    entry = {
        "date": today_str(),
        "top_traders": [
            t.get("id", t.get("username", "?"))
            for t in traders_data.get("top_traders", [])[:10]
        ],
        "top_polymarket": [
            t.get("id", t.get("username", "?"))
            for t in pm_data.get("top_traders", [])[:10]
        ],
        "confluence_alerts": [
            {"symbol": c["symbol"], "direction": c["direction"], "confidence": c["confidence_label"]}
            for c in confluence.get("confluences", [])
        ],
        "market_sentiment": confluence.get("signal_breakdown", {}),
    }
    
    memory["daily_recommendations_log"].append(entry)
    
    # Keep only last 90 days of logs
    if len(memory["daily_recommendations_log"]) > 90:
        memory["daily_recommendations_log"] = memory["daily_recommendations_log"][-90:]
    
    # Update accuracy metrics
    metrics = memory["accuracy_metrics"]
    metrics["total_recommendations"] = len(memory["daily_recommendations_log"])
    
    # Count unique traders tracked
    all_trad = set()
    all_pm = set()
    for log in memory["daily_recommendations_log"]:
        all_trad.update(log.get("top_traders", []))
        all_pm.update(log.get("top_polymarket", []))
    
    return memory

def compute_rolling_accuracy(memory):
    """Compute rolling 30-day accuracy from memory data."""
    trad = memory["traditional_traders"]
    pm = memory["polymarket_traders"]
    
    total_hits = sum(v.get("hits", 0) for v in trad.values())
    total_misses = sum(v.get("misses", 0) for v in trad.values())
    total = total_hits + total_misses
    
    pm_correct = sum(v.get("resolved_correct", 0) for v in pm.values())
    pm_incorrect = sum(v.get("resolved_incorrect", 0) for v in pm.values())
    pm_total = pm_correct + pm_incorrect
    
    memory["accuracy_metrics"]["rolling_30_day_accuracy"] = {
        "traditional": {
            "hits": total_hits,
            "misses": total_misses,
            "accuracy": round(total_hits / total, 4) if total > 0 else None,
        },
        "polymarket": {
            "correct": pm_correct,
            "incorrect": pm_incorrect,
            "accuracy": round(pm_correct / pm_total, 4) if pm_total > 0 else None,
        },
    }
    return memory

# ─── Main ────────────────────────────────────────────────────────────────────

def main():
    print(f"{'='*60}")
    print(f"  MEMORY UPDATER — {today_str()}")
    print(f"{'='*60}")
    
    config = load_config()
    date = today_str()
    
    # Load today's data
    traders = load_json(f"top_traders_{date}.json")
    pm_traders = load_json(f"polymarket_traders_{date}.json")
    confluence = load_json(f"confluence_{date}.json")
    
    # Load and update memory
    memory = load_memory()
    
    print("\n[1/4] Updating traditional trader memory...")
    memory = update_traditional_traders(memory, traders, config)
    print(f"  Tracking {len(memory['traditional_traders'])} traditional traders")
    
    print("\n[2/4] Updating Polymarket trader memory...")
    memory = update_polymarket_traders(memory, pm_traders, config)
    print(f"  Tracking {len(memory['polymarket_traders'])} Polymarket traders")
    
    print("\n[3/4] Logging daily recommendations...")
    memory = log_daily_recommendation(memory, traders, pm_traders, confluence)
    print(f"  Total logged days: {len(memory['daily_recommendations_log'])}")
    
    print("\n[4/4] Computing rolling accuracy...")
    memory = compute_rolling_accuracy(memory)
    acc = memory["accuracy_metrics"]["rolling_30_day_accuracy"]
    if acc:
        trad_acc = acc.get("traditional", {}).get("accuracy")
        pm_acc = acc.get("polymarket", {}).get("accuracy")
        if trad_acc is not None:
            print(f"  Traditional accuracy: {trad_acc:.1%}")
        if pm_acc is not None:
            print(f"  Polymarket accuracy: {pm_acc:.1%}")
    
    # Save
    save_memory(memory)
    
    print(f"\n{'='*60}")
    print(f"  Memory updated and saved")
    print(f"  File: {MEMORY_PATH}")
    print(f"{'='*60}")

if __name__ == "__main__":
    main()
